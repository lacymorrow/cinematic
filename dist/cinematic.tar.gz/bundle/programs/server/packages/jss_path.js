(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var path, util;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/jss:path/path.js                                         //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
util = Npm.require('util-is');                                       // 1
path = Npm.require('path');                                          // 2
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jss:path'] = {
  path: path
};

})();

//# sourceMappingURL=jss_path.js.map
