(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var assert;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/peerlibrary:assert/server.js                             //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
assert = Npm.require('assert');                                      // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['peerlibrary:assert'] = {
  assert: assert
};

})();

//# sourceMappingURL=peerlibrary_assert.js.map
