(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['bdunnette:snapjs'] = {};

})();

//# sourceMappingURL=bdunnette_snapjs.js.map
